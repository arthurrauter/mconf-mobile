The Simpsons Movie - Theatrical Trailer

Synopsis: Homer accidentally causes a radioactive leak into the river, does this condemn Springfield so that these inhabitants can never go back? This is the first full-length feature film from the long-running Fox television series.

Original Video properties :
	Resolution : 720p (1280x544)
	FPS : 23.976 (NTSC)

Video Codec : H.264
Codec (Encoding Only) Download : http://www.divx-digest.com/software/x264.html

Trailer Resolution: 720p (1280x544)

Audio Codec : AAC
Resolution : 48 kHz

Trailer Size : 70 MB


Converted to H.264 using MeGUI:

http://www.digital-digest.com/articles/MeGUI_H.264_Conversion_Guide_page1.html


Playback instructions:

http://www.digital-digest.com/articles/mp4_h264_playback_page1.html

Copyright : 2007, Fox